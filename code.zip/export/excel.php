<?php
// Database connection parameters
$host = 'localhost';
$db   = 'repositorio';
$user = 'root';
$pass = 'root';
$port = 3307;
$charset = 'utf8mb4';

// Create a DSN string
$dsn = "mysql:host=$host;dbname=$db;port=$port;charset=$charset";
// Set options
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

function filterData(&$str){
    $str = preg_replace("/\t/", "\\t", $str);
    $str = preg_replace("/\r?\n/", "\\n", $str);
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
}
 

try {
    // Connect to the database
    $pdo = new PDO($dsn, $user, $pass, $options);

    // Filter the excel data

    // Excel file name for download
    $fileName = "documents-data_" . date('Y-m-d') . ".xls";
    
    
    // Column names
    $fields = array('Document', 'Description', 'Emplacement', 'Folio', 'Adressé à', 'Assisté', 'État', 'Date');
    
    // Display column names as first row
    $excelData = implode("\t", array_values($fields)) . "\n";
    
    // Fetch records from database
    //$query = $db->query("SELECT * FROM members ORDER BY id ASC");
    $stmt = $pdo->prepare("SELECT c.id_carpeta, c.nombre FROM carpeta c INNER JOIN periodocarpeta p ON c.id_carpeta = p.carpeta_id WHERE p.periodo_id = ?");
    $stmt->execute([$periodId]);
    if($query->num_rows > 0){ 
        // Output each row of the data
        while($row = $query->fetch_assoc()){
            $status = ($row['status'] == 1)?'Active':'Inactive';
            $lineData = array($row['id'], $row['first_name'], $row['last_name'], $row['email'], $row['gender'], $row['country'], $row['created'], $status);
            array_walk($lineData, 'filterData');
            $excelData .= implode("\t", array_values($lineData)) . "\n";
        }
    }else{
        $excelData .= 'No records found...'. "\n";
    }
 
    // Headers for download
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment;filename=\"$fileName\"");
    
    // Render excel data
    echo $excelData;
    
    exit;
}catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}
?>